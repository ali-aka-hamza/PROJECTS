-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2020 at 12:12 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ums`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `Faculty_Name` varchar(20) NOT NULL,
  `age` int(3) NOT NULL,
  `Adress` varchar(30) NOT NULL,
  `Education` varchar(20) NOT NULL,
  `DOB` varchar(15) NOT NULL,
  `CNIC` varchar(20) NOT NULL,
  `Phone_No` varchar(20) NOT NULL,
  `Department_Name` varchar(20) NOT NULL,
  `Department_Id` int(5) NOT NULL,
  `Faculty_ID` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `facultyattendence`
--

CREATE TABLE `facultyattendence` (
  `Faculty_ID` int(5) NOT NULL,
  `Attendance` varchar(10) NOT NULL,
  `Date1` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_name`, `password`) VALUES
('sohaib', 's0000'),
('sohaib', 's0000');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Student_Name` varchar(50) NOT NULL,
  `Father_Name` varchar(50) NOT NULL,
  `Adress` varchar(50) NOT NULL,
  `Emaill` varchar(50) NOT NULL,
  `Rol_No` int(5) NOT NULL,
  `Department_Id` int(10) NOT NULL,
  `DOB` varchar(20) NOT NULL,
  `CNIC` varchar(20) NOT NULL,
  `FSC_Percentage` int(5) NOT NULL,
  `Department_Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Student_Name`, `Father_Name`, `Adress`, `Emaill`, `Rol_No`, `Department_Id`, `DOB`, `CNIC`, `FSC_Percentage`, `Department_Name`) VALUES
('s1', '1', '1', '1', 1, 1, '1', '1', 1, 'BBA');

-- --------------------------------------------------------

--
-- Table structure for table `studentattendence`
--

CREATE TABLE `studentattendence` (
  `Rol_No` int(5) NOT NULL,
  `Present_Absent` varchar(10) NOT NULL,
  `Date1` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentattendence`
--

INSERT INTO `studentattendence` (`Rol_No`, `Present_Absent`, `Date1`) VALUES
(1, 'PRESENT', '34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`Faculty_ID`);

--
-- Indexes for table `facultyattendence`
--
ALTER TABLE `facultyattendence`
  ADD KEY `Faculty_ID` (`Faculty_ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Rol_No`);

--
-- Indexes for table `studentattendence`
--
ALTER TABLE `studentattendence`
  ADD KEY `Rol_No` (`Rol_No`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `facultyattendence`
--
ALTER TABLE `facultyattendence`
  ADD CONSTRAINT `facultyattendence_ibfk_1` FOREIGN KEY (`Faculty_ID`) REFERENCES `faculty` (`Faculty_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `studentattendence`
--
ALTER TABLE `studentattendence`
  ADD CONSTRAINT `studentattendence_ibfk_1` FOREIGN KEY (`Rol_No`) REFERENCES `student` (`Rol_No`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
