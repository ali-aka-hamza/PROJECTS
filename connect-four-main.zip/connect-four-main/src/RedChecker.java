public class RedChecker extends Checker {
	public RedChecker() {
		super(CheckerColor.RED);
	}
}
