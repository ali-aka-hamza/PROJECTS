/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traffic;

/**
 *
 * @author hamzah
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Vector;

/**
 *
 * @author Oltion
 */
public class CSVReader {
     public static Vector v1 ,v2;
     public static String arr[];
   

    public static ArrayList<String> readFile(String fileName)
    {
        ArrayList<String> fileContents = new ArrayList<>();
          int num = 0 ;
            String nu[];
          String dir[] = null;
        try
        {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            String line = "";
            
            bufferedReader.readLine();
            
           
            while((line = bufferedReader.readLine()) != null)
            {
                //arr = null;
                fileContents.add(line);
                System.out.println(line);
                //arr = line.split(",");
                
                //System.out.println(arr[1]+"\t"+arr[arr.length-1]);

            }
            
            
        }
        catch(Exception e)
        {
            System.out.println("Error reading the file: " + e.getMessage());
        }
        
        return fileContents;
    }
}
