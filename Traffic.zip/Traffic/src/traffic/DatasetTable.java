/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traffic;

/**
 *
 * @author hamzah
 */
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Oltion
 */
public class DatasetTable {
    private static Connection connection = DatasetDB.getConnection();
    
    public static void insert(int CountID, String DirectionOfTravel, int CountYear, String CountDate, int CountHour, int RegionID, String Region_Name, int Local_AuthorityID, String Local_Authority_Name, String Road_Name, String Road_Type, String Start_Junction, String End_Junction, String Road_Length_KM, String Road_Length_Miles, int Pedal_Cycles, int two_wheeled_vehicles, int cars_and_taxis, int buses_and_coaches, int lgvs, int hgvs_2_rigid_axle, int hgvs_3_rigid_axle, int hgvs_4_or_more_rigid_axle, int hgvs_3_or_4_articulated_axle, int hgvs_5_articulated_axle, int hgvs_6_articulated_axle, int all_hgvs, int all_motor_vehicles)
    {
        String sql1 = "INSERT INTO Count_Point (CountID, DirectionOfTravel, CountYear, CountDate, CountHour, Local_AuthorityID) VALUES"
                + "("
                    + "'" + CountID + "',"
                    + "'" + DirectionOfTravel + "',"
                    + "'" + CountYear + "',"
                    + "'" + CountDate + "',"
                    + "'" + CountHour + "',"
                    + "'" + Local_AuthorityID + "'"
                + ");"
                 
                + "INSERT INTO Region (RegionID, Region_Name) VALUES"
                + "("
                    + "'" + RegionID + "',"
                    + "'" + Region_Name + "'"
                + ");"
         
                + "INSERT INTO Local_Authority (Local_AuthorityID, Local_Authority_Name, RegionID) VALUES"
                + "("
                    + "'" + Local_AuthorityID + "',"
                    + "'" + Local_Authority_Name + "',"
                    + "'" + RegionID + "'"
                + ");"
         
                + "INSERT INTO Road (Road_Name, Road_Type, Start_Junction, End_Junction, Road_Length_KM, Road_Length_Miles) VALUES"
                + "("
                    + "'" + Road_Name + "',"
                    + "'" + Road_Type + "',"
                    + "'" + Start_Junction + "',"
                    + "'" + End_Junction + "',"
                    + "'" + Road_Length_KM + "',"
                    + "'" + Road_Length_Miles + "'"
                + ");"
                 
                + "INSERT INTO Vehicles (Local_AuthorityID, Pedal_Cycles, two_wheeled_vehicles, cars_and_taxis, buses_and_coaches, lgvs, hgvs_2_rigid_axle, hgvs_3_rigid_axle, hgvs_4_or_more_rigid_axle, hgvs_3_or_4_articulated_axle, hgvs_5_articulated_axle, hgvs_6_articulated_axle, all_hgvs, all_motor_vehicles) VALUES"
                + "("
                    + "'" + Local_AuthorityID + "',"
                    + "'" + Pedal_Cycles + "',"
                    + "'" + two_wheeled_vehicles + "',"
                    + "'" + cars_and_taxis + "',"
                    + "'" + buses_and_coaches + "',"
                    + "'" + lgvs + "',"
                    + "'" + hgvs_2_rigid_axle + "',"
                    + "'" + hgvs_3_rigid_axle + "',"
                    + "'" + hgvs_4_or_more_rigid_axle + "',"
                    + "'" + hgvs_3_or_4_articulated_axle + "',"
                    + "'" + hgvs_5_articulated_axle + "',"
                    + "'" + hgvs_6_articulated_axle + "',"
                    + "'" + all_hgvs + "',"
                    + "'" + all_motor_vehicles + "'"
                + ");";
        
        try
        {
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql1);
            //System.out.println("Dataset inserted successfully.");
        }
        catch (Exception e)
        {
            System.out.println("Error while inserting into Region table: " + e.getMessage());
        }
    }
    
    public static void batchInsert(ArrayList<String> input)
    {
        for(String currentLine : input)
        {
            String[] lineArray = currentLine.split(",");
            int CountID = Integer.parseInt(lineArray[0]);
            String DirectionOfTravel = lineArray[1];
            int CountYear  = Integer.parseInt(lineArray[2]);
            String CountDate = lineArray[3];
            int CountHour = Integer.parseInt(lineArray[4]);
            int RegionID = Integer.parseInt(lineArray[5]);
            String Region_Name = lineArray[6];
            int Local_AuthorityID = Integer.parseInt(lineArray[7]);
            String Local_Authority_Name = lineArray[8];
            String Road_Name = lineArray[9];
            String Road_Type = lineArray[10];
            String Start_Junction = lineArray[11];
            String End_Junction = lineArray[12];
            String Road_Length_KM = lineArray[17];
            String Road_Length_Miles = lineArray[18];
            int Pedal_Cycles = Integer.parseInt(lineArray[19]);
            int two_wheeled_vehicles = Integer.parseInt(lineArray[20]);
            int cars_and_taxis = Integer.parseInt(lineArray[21]);
            int buses_and_coaches = Integer.parseInt(lineArray[22]);
            int lgvs = Integer.parseInt(lineArray[23]);
            int hgvs_2_rigid_axle = Integer.parseInt(lineArray[24]);
            int hgvs_3_rigid_axle = Integer.parseInt(lineArray[25]);
            int hgvs_4_or_more_rigid_axle = Integer.parseInt(lineArray[26]);
            int hgvs_3_or_4_articulated_axle = Integer.parseInt(lineArray[27]);
            int hgvs_5_articulated_axle = Integer.parseInt(lineArray[28]);
            int hgvs_6_articulated_axle = Integer.parseInt(lineArray[29]);
            int all_hgvs = Integer.parseInt(lineArray[30]);
            int all_motor_vehicles = Integer.parseInt(lineArray[31]);
            insert(CountID, DirectionOfTravel, CountYear, CountDate, CountHour, RegionID, Region_Name, Local_AuthorityID, Local_Authority_Name, Road_Name, Road_Type, Start_Junction, End_Junction, Road_Length_KM, Road_Length_Miles, Pedal_Cycles, two_wheeled_vehicles, cars_and_taxis, buses_and_coaches, lgvs, hgvs_2_rigid_axle, hgvs_3_rigid_axle, hgvs_4_or_more_rigid_axle, hgvs_3_or_4_articulated_axle, hgvs_5_articulated_axle, hgvs_6_articulated_axle, all_hgvs, all_motor_vehicles);
        }
    }
}
