/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traffic;

/**
 *
 * @author hamzah
 */

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;

/**
 *
 * @author Oltion
 */
public class DatasetDB {
    public static Connection getConnection()
    {
        String urlSQLite = "jdbc:sqlite:Dataset.db";
        
        try
        {
            Driver driverSQLite = new org.sqlite.JDBC();
            DriverManager.registerDriver(driverSQLite);
            System.out.println("SQLite Driver loaded successfully.");
        }
        catch(Exception e)
        {
            System.out.println("Issue with SQLite driver: " + e.getMessage());
        }
        
        Connection connection = null;
        
        try
        {
            connection = DriverManager.getConnection(urlSQLite);
            System.out.println("Successfully connected to database.");
        }
        catch(Exception e)
        {
            System.out.println("Error connection to database " + e.getMessage());
        }
        
        return connection;
    }
}
