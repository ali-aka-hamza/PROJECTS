/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traffic;

/**
 *
 * @author hamzah
 */
import java.sql.Connection;
import java.sql.Statement;
/**
 *
 * @author Oltion
 */
public class Tables {
    public static void createDataset()
    {
        Connection connection = DatasetDB.getConnection();
        
         String sql1 = "CREATE TABLE if not exists Count_Point"
                + "("
                    + "CountID INTEGER,"
                    + "DirectionOfTravel VARCHAR,"
                    + "CountYear INTEGER,"
                    + "CountDate VARCHAR,"
                    + "CountHour INTEGER,"
                    + "Local_AuthorityID INTEGER"
                + ");"
                 
                + "CREATE TABLE if not exists Region"
                + "("
                    + "RegionID INTEGER,"
                    + "Region_Name VARCHAR"
                + ");"
         
                + "CREATE TABLE if not exists Local_Authority"
                + "("
                    + "Local_AuthorityID INTEGER,"
                    + "Local_Authority_Name VARCHAR,"
                    + "RegionID INTEGER"
                + ");"
         
                + "CREATE TABLE if not exists Road"
                + "("
                    + "Road_Name VARCHAR,"
                    + "Road_Type VARCHAR,"
                    + "Start_Junction VARCHAR,"
                    + "End_Junction VARCHAR,"
                    + "Road_Length_KM VARCHAR,"
                    + "Road_Length_Miles VARCHAR"
                + ");"
                 
                + "CREATE TABLE if not exists Vehicles"
                + "("
                    + "Local_AuthorityID INTEGER,"
                    + "Pedal_Cycles INTEGER,"
                    + "two_wheeled_vehicles INTEGER,"
                    + "cars_and_taxis INTEGER,"
                    + "buses_and_coaches INTEGER,"
                    + "lgvs INTEGER,"
                    + "hgvs_2_rigid_axle INTEGER,"
                    + "hgvs_3_rigid_axle INTEGER,"
                    + "hgvs_4_or_more_rigid_axle INTEGER,"
                    + "hgvs_3_or_4_articulated_axle INTEGER,"
                    + "hgvs_5_articulated_axle INTEGER,"
                    + "hgvs_6_articulated_axle INTEGER,"
                    + "all_hgvs INTEGER,"
                    + "all_motor_vehicles INTEGER"
                + ");";
         
         try
        {
            Statement sqlStatement = connection.createStatement();
            sqlStatement.executeUpdate(sql1);
            System.out.println("Dataset table created.");
        }
        catch (Exception e)
        {
            System.out.println("Error creating tables: " + e.getMessage());
        }
    }
}

