/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traffic;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.EventQueue;
import org.jfree.chart.ChartFrame;

/**
 *
 * @author hamzah
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;

/**
 *
 * @author Oltion
 */
public class Traffic {

   
    public static void main(String[] args) 
    {
         JFrame jf = new JFrame();
        NewJPanel h = new NewJPanel();
        
      
        h.setSize(100,100);

       
        jf.add(h);
        jf.pack();
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setVisible(true);
        Tables.createDataset();
        
        ArrayList<String> fileContents = CSVReader.readFile("d.csv");
        DatasetTable.batchInsert(fileContents);
        
        //System.out.println(fileContents);
    }
    
}
