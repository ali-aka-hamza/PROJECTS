
package demo;
/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/

public class batchprop {
 private int bid;
    private String btime;
    public void setId(int i)
    {
        bid=i;
    }
    public int getId()
    {
        return bid;
    }
    public void setName(String n)
    {
        btime=n;
    }
    public String getName()
    {
        return btime;
    }
        
}
