
package demo;
/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/

public class appprop {
     private int aid;
    private String aname;
      private String fname;
      private String address;
      private long contact;
      private String email;
      private String dob;
      private String gender;
      private String gametype;
      private String game;
      private String batch;
      private String court;
      private String coach;
      
      private String pack;
      private long fee;
            
    public void setId(int i)
    {
        aid=i;
    }
    public int getId()
    {
        return aid;
    }
     public void setContact(long i)
    {
        contact=i;
    }
    public long getContact()
    {
        return contact;
    }
    public void setName(String n)
    {
        aname=n;
    }
    public String getName()
    {
        return aname;
    }
      public void setFname(String n)
    {
        fname=n;
    }
    public String getFname()
    {
        return fname;
    }
       public void setAddress(String n)
    {
        address=n;
    }
    public String getAddress()
    {
        return address;
    }
       public void setEmail(String n)
    {
        email=n;
    }
    public String getEmail()
    {
        return email;
    }
       public void setDob(String n)
    {
        dob=n;
    }
    public String getDob()
    {
        return dob;
    }
       public void setGametype(String n)
    {
        gametype=n;
    }
    public String getGametype()
    {
        return gametype;
    }
    
       public void setGame(String n)
    {
        game=n;
    }
    public String getGame()
    {
        return game;
    }
       
       public void setBatch(String n)
    {
        batch=n;
    }
    public String getBatch()
    {
        return batch;
    }
       public void setCoach(String n)
    {
        coach=n;
    }
    public String getCoach()
    {
        return coach;
    }
    
       public void setCourt(String n)
    {
        court=n;
    }
    public String getCourt()
    {
        return court;
    }
       public void setGender(String n)
    {
        gender=n;
    }
    public String getGender()
    {
        return gender;
    }
     public void setPackage(String n)
    {
        pack=n;
    }
    public String getPackage()
    {
        return pack;
    }
     public void setFee(long n)
    {
        fee=n;
    }
    public long getFee()
    {
        return fee;
    }
    
    
    
    
}
