
package demo;
/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/

public interface provider {
    String Driver="oracle.jdbc.driver.OracleDriver";
    String connectionUrl="jdbc:oracle:thin:@localhost:1521:XE";
    String username="hr";
    String password="oracle";
    
}