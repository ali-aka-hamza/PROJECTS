
package demo;

/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/
public class packprop {
     private String pack;
    private int amount;
    private int id;
     public void setId(int i)
    {
      id=i;
    }
    public int getId()
    {
        return id;
    }
    public void setAmount(int a)
    {
        amount=a;
    }
    public int getAmount()
    {
        return amount;
    }
    public void setPack(String p)
    {
        pack=p;
    }
    public String getPack()
    {
        return pack;
    }
    
}
