/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/
public class courtprop {
     private int cid;
    private String cname;
    public void setId(int i)
    {
        cid=i;
    }
    public int getId()
    {
        return cid;
    }
    public void setName(String n)
    {
        cname=n;
    }
    public String getName()
    {
        return cname;
    }
    
}
