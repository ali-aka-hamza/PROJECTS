/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/
public class outprop {
    private int gameid;
    private String gname;
    public void setId(int i)
    {
        gameid=i;
    }
    public int getId()
    {
        return gameid;
    }
    public void setName(String n)
    {
        gname=n;
    }
    public String getName()
    {
        return gname;
    }
}
