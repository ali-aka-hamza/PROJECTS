
package demo;
/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/

public class prop {
    private int gid;
    private String gname;
    public void setId(int i)
    {
        gid=i;
    }
    public int getId()
    {
        return gid;
    }
    public void setName(String n)
    {
        gname=n;
    }
    public String getName()
    {
        return gname;
    }
}
