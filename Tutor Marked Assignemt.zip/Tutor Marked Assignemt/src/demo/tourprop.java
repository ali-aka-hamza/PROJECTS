
package demo;
/***********************************************************************
 * 
 * NAME         :       OMAR SAID       
 * 
 * ID           :       190392
 * 
 ***********************************************************************/

public class tourprop 
{
    private int id;
     private String name;
      private String address;
      private long contact;
      private String email;
      private String gender;
      private String gametype;
      private String game;
      private String court;
      private String time;
      private String dates;
      private String day;
      public void setId(int i)
    {
        id=i;
    }
    public int getId()
    {
        return id;
    }
     public void setContact(long i)
    {
        contact=i;
    }
    public long getContact()
    {
        return contact;
    }
    public void setName(String n)
    {
        name=n;
    }
    public String getName()
    {
        return name;
    }
     
       public void setAddress(String n)
    {
        address=n;
    }
    public String getAddress()
    {
        return address;
    }
       public void setEmail(String n)
    {
        email=n;
    }
    public String getEmail()
    {
        return email;
    }
  
       public void setGametype(String n)
    {
        gametype=n;
    }
    public String getGametype()
    {
        return gametype;
    }
       public void setGender(String n)
    {
        gender=n;
    }
    public String getGender()
    {
        return gender;
    }
 
         public void setGame(String n)
    {
        game=n;
    }
    public String getGame()
    {
        return game;
    }
          public void setCourt(String n)
    {
        court=n;
    }
    public String getCourt()
    {
        return court;
    }
       public void setTime(String n)
    {
        time=n;
    }
    public String getTime()
    {
        return time;
    }
           public void setDate(String n)
    {
        dates=n;
    }
    public String getDate()
    {
        return dates;
    }
    public void setDay(String n)
    {
        day=n; 
    }
    public String getDay()
    {
        return day;
        
    }
    }