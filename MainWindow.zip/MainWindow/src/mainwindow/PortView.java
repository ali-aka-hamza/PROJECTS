/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainwindow;

/**
 *
 * @author raheel
 */

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;

import java.awt.TextArea;

import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.filechooser.FileSystemView;
import javax.usb.UsbDevice;

import javax.usb.UsbException;

import org.usb4java.Context;
import org.usb4java.Device;
import org.usb4java.DeviceDescriptor;
import org.usb4java.DeviceList;
import org.usb4java.LibUsb;
import org.usb4java.LibUsbException;

public class PortView extends JPanel{
        String ss;
         FileWriter myWriter ;
      //  ListDevices ld = new ListDevices();
	JFrame f = new JFrame("Port View");
        Container c = f.getContentPane();
     //   c.setLayout(new BorderLayout());        
        ImageIcon ii = new ImageIcon("io2.jpg") ;
        JLabel bgimg = new JLabel("",ii,JLabel.CENTER);
        TextArea tt;
        JScrollPane scroll ; 
	JPanel viewer = new JPanel();
	JMenuBar mb = new JMenuBar();
        JButton b = new JButton("Device Info");
	JMenu io = new JMenu("I/O Explorer");
	JMenu scan = new JMenu("Scan");
	JMenu settings = new JMenu("Settings");
	JMenuItem newScan = new JMenuItem("New Scan");
	JMenuItem stopScan = new JMenuItem("Stop Scan");
	JMenuItem color = new JMenuItem("Color");
	JMenuItem setup = new JMenuItem("Setup");
	JMenuItem list = new JMenuItem("list");
	MyPanel p ;
        String st;
        String arr[] , arr2[];
        File file;
        BufferedReader br ;
                PortView() throws IOException, UsbException{
                
                myWriter = new FileWriter("/home/hamzah/NetBeansProjects/MainWindow/src/mainwindow/DeviceReport.txt", true);
	
                ListUsb();
                show();
                f.setSize(600, 600);
		f.setLayout(null);
		f.setVisible(true);
		f.setJMenuBar(mb);
		f.add(mb);
                 tt = new TextArea();
//                .add(p);
                f.add(bgimg);
                bgimg.setBounds(140,20,400,200); 
		f.add(viewer);
                b.setBounds(4,70,130,40);
		viewer.setBounds(150, 75, 300, 90);
		viewer.setBackground(Color.gray);
		viewer.setVisible(true);
		mb.add(io);
                f.add(b);
		mb.add(scan);
		mb.add(settings);
		io.add(setup);
		io.add(list);
		scan.add(newScan);
		scan.add(stopScan);
		settings.add(color);
                tt.setText(ss);
                scroll = new JScrollPane(tt);
              
                tt.setEditable(false);
                tt.setBounds(10,230,570,290);
                f.add(tt);
                 myWriter.close();
		b.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae)
                {
                    try {
                        DevicePanel p = new DevicePanel();
                    } catch (IOException ex) {
                        Logger.getLogger(PortView.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }});
                
	}
   
           
               public void ListUsb() throws IOException, UsbException
               {
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
                   Context context = new Context();
                   UsbDevice d ;

        int result = LibUsb.init(context);
     
        if (result < 0)
        {
            throw new LibUsbException("Unable to initialize libusb", result);
        }

        DeviceList list = new DeviceList();

        result = LibUsb.getDeviceList(context, list);
          
        if (result < 0)
        {
            throw new LibUsbException("Unable to get device list", result);
        }

        try
        {
          
           ss="";
           
            for (Device device: list)
            {
                st="";
                file = new File("/home/hamzah/NetBeansProjects/MainWindow/src/mainwindow/Id");
                br = new BufferedReader(new FileReader(file));
                int address = LibUsb.getDeviceAddress(device);
                         
                int busNumber = LibUsb.getBusNumber(device);
                DeviceDescriptor descriptor = new DeviceDescriptor();
                
                result = LibUsb.getDeviceDescriptor(device, descriptor);
                if (result < 0)
                {
                    throw new LibUsbException(
                        "Unable to read device descriptor", result);
                }
          String Vid = String.format("%04x",descriptor.idVendor());    
          String Dna = String.format("%04x%n", descriptor.idProduct());
          String as = Dna.trim();
          String Bnum =String.format("%04d",busNumber);
          //          System.out.println(Vid+"\t"+Dna);
          String dr ;
        
      while ((st = br.readLine()) != null)
        {
            boolean x = true ;
            arr = null;
            arr = st.split("  ");
            if(arr[0].equals(Vid))
            {
               ss+= "\n"+dtf.format(LocalDateTime.now());
                while((st = br.readLine()) != null && st.charAt(0)  == '\t')
                {
                    arr2 = null ;
                    arr2 = st.split("  ");
                
                    String b = arr2[0].trim();
                   
                    if(b.equals(as))
                    {
                       ss+="\nManufacturer:\t\t"+arr[1]+"\nDevice Type:\t\t"+arr2[1]+"\nBus No#:\t\t"+Bnum+"\n"+"\nLocation:\t\t USB Input Device";
                        x= false;
                    }
                   
                }
                if(x)
                ss+="\nManufacturer:\t\t"+arr[1]+"\nDevice Type:\t\tUnknown External Device\nBus No#:\t\t"+Bnum+"\n"+"\nLocation:\t\t USB Input Device";
            
            }
            
        }
}
        myWriter.write(ss);
        }
        finally
        {
   
            LibUsb.freeDeviceList(list, true);
        }

        LibUsb.exit(context);
    }
               
       
}
