/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainwindow;

import java.awt.TextArea;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author hamzah
 */
public class DevicePanel {
    JFrame ff = new JFrame("Device Info");
    JLabel lb ;
    TextArea ta;
     FileWriter myWriter ;
    DevicePanel() throws IOException
    {
        myWriter = new FileWriter("/home/hamzah/NetBeansProjects/MainWindow/src/mainwindow/DriveReport.txt",true);
        lb = new JLabel();
        String s = null;
        ta = new TextArea();
        //lb.setText("");
       
    s = "File system roots returned ";
    FileSystemView fsv = FileSystemView.getFileSystemView();
    File[] roots = fsv.getRoots();
    for (int i = 0; i < roots.length; i++)
    {
        s += "\nRoot: " + roots[i];
    }

    s+="\nHome directory: " + fsv.getHomeDirectory();

    s+="\nFile system roots returned by File.listRoots():";
    File[] f = File.listRoots();
    for (int i = 0; i < f.length; i++)
    {
        s+="\nDrive: " + f[i];
        s+="\nDisplay name: " + fsv.getSystemDisplayName(f[i]);
        s+="\nIs drive: " + fsv.isDrive(f[i]);
        s+="\nReadable: " + f[i].canRead();
        s+="\nWritable: " + f[i].canWrite();
        s+="\nTotal space: " + f[i].getTotalSpace();
        s+="\nUsable space: " + f[i].getUsableSpace();
    }
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
        //lb.setText(s);
        myWriter.write(""+dtf.format(LocalDateTime.now())+"\n\n"+s);
        ta.setText(s);
        ta.setBounds(10,5,470,370);
        ff.add(ta);
        ta.setEditable(false);
        ff.setSize(500, 400);
	ff.setLayout(null);
	ff.setVisible(true);
        myWriter.close();        
    }
    
}
