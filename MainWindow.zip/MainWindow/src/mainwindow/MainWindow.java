/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainwindow;

/**
 *
 * @author hamzah
 */
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.usb.UsbException;

public class MainWindow implements ActionListener {
	JFrame f = new JFrame("Main Window");
	JButton pView = new JButton("Port View");
         ImageIcon ii = new ImageIcon("bg.jpg") ;
        JLabel bgimg = new JLabel("",ii,JLabel.CENTER);
	JButton qReport = new JButton("Quick Report");
	JButton admin = new JButton("Admin Panel");
	JMenu ioM = new JMenu("I/O Explorer");
	JMenu serverM = new JMenu("Server");
	JMenuItem hide = new JMenuItem("Hide to taskbar");
	JMenuItem shutdown = new JMenuItem("Shutdown");
	JMenuItem serverStart = new JMenuItem("Start Server");
	JMenuItem serverShut = new JMenuItem("Shutdown Server");
	JMenuItem serverSettings = new JMenuItem("settings");
	JMenuBar mb = new JMenuBar();
      //  public FileWriter  myWriter;
	MainWindow() throws IOException {
       // myWriter = new FileWriter("/home/hamzah/NetBeansProjects/MainWindow/src/mainwindow/Report.txt");
		f.setSize(600, 600);
		f.setLayout(null);
		f.setVisible(true);
		f.setJMenuBar(mb);
		pView.setBounds(190, 80, 140, 80);
		qReport.setBounds(190, 230, 140, 80);
		admin.setBounds(190, 380, 140, 80);
		ioM.add(hide);
		ioM.add(shutdown);
		serverM.add(serverStart);
		serverM.add(serverShut);
		serverM.add(serverSettings);
		mb.add(ioM);
		mb.add(serverM);
		f.add(pView);
		f.add(qReport);
		f.add(admin);
                f.add(bgimg);
                bgimg.setBounds(0,20,800,800);
		f.add(mb);
		pView.addActionListener(this);
		shutdown.addActionListener(this);
		admin.addActionListener(this);
                qReport.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae)
                {
                     JFrame fd =new JFrame();  
                    JOptionPane.showMessageDialog(fd,"Data of Drives & USB Devices has been save in text file in scr folder ");  
                }});

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == pView) //Open Port View
			try {
                            new PortView();
                } catch (IOException ex) {
                    Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UsbException ex) {
                    Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
		
		if (e.getSource() == admin ) //Open Admin Panel
			new loginPanel();
			
		if (e.getSource() == shutdown) //close app
                    System.exit(0);
                
                        
		
		

			
	}

	public static void main(String[] args) throws IOException {
		new MainWindow();
	}

}