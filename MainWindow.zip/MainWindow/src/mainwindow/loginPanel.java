/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainwindow;

/**
 *
 * @author raheel
 */

import javax.swing.*;
import java.awt.event.*;

public class loginPanel implements ActionListener{
	JFrame f = new JFrame("Admin Panel");
	final JLabel user = new JLabel();
	final JPasswordField pass = new JPasswordField();
	JButton login = new JButton("Login");
	final JLabel label = new JLabel();
	final JTextArea text = new JTextArea();
	JLabel l1 = new JLabel("Authorized User: ");
	JLabel l2 = new JLabel("Password: ");
	
	final String loginName = "Mace"; //replace with get username method
	final String loginPass = "passW"; //replace with get password method
	// will com. with server for login info
	loginPanel(){
		f.add(pass);
		f.add(label);
		f.add(l1);
		f.add(l2);
		f.add(login);
		f.add(text);
		l1.setBounds(15, 15, 120, 30);
		text.setBounds(100, 15, 120, 25);
		l2.setBounds(15, 60, 120, 30);
		pass.setBounds(100, 62, 120, 25);
		login.setBounds(100, 100, 100, 50);
		f.setSize(300, 250);
		f.setVisible(true);
		f.setLayout(null);
		login.addActionListener(this);
		

		
	}
	
	public void actionPerformed(ActionEvent e) {
		//if (e.getSource() == login) {
			//if(text.getText().equals(login) && pass.getPassword().equals(loginPass))
				//AdminPanel();
			
			
		//}
		
	}
	


}